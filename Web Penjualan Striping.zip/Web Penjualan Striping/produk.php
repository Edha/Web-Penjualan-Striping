<!DOCTYPE HTML>
<html>

<head>
  <title>STRIPING CUSTOM</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" />
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.html">Striping<span class="logo_colour">Custom</span></a></h1>
          <h2>Rego Gowo Rupo - Desain Sakarepmu</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="index.html">Beranda</a></li>
		  <li class="selected"><a href="data.php">Input Data</a></li>
          <li><a href="hitung_harga.php">Hitung Harga</a></li>
          <li><a href="laporan.php">Laporan</a></li>
        </ul>
      </div>
    </div>
    <div id="content_header"></div>
    <div id="site_content">
      <div id="banner"></div>
	  <div id="sidebar_container">
        <div class="sidebar">
          <div class="sidebar_top"></div>
          <div class="sidebar_item">
            <!-- insert your sidebar items here -->
            <h3>Daftar Order</h3>
			<ul>
              <li><a href="#">Senin</a></li>
              <li><a href="#">Selasa</a></li>
              <li><a href="#">Rabu</a></li>
              <li><a href="#">Kamis</a></li>
			  <li><a href="#">Jum'at</a></li>
			  <li><a href="#">Sabtu</a></li>
			  <li><a href="#">Minggu</a></li>
            </ul>
		  </div>
          <div class="sidebar_base"></div>
        </div>
        <div class="sidebar">
          <div class="sidebar_top"></div>
          <div class="sidebar_item">
            <h3>Cek Ongkir</h3>
            <ul>
              <li><a href="#">JNE</a></li>
              <li><a href="#">POS</a></li>
              <li><a href="#">TIKI</a></li>
              <li><a href="#">J&T</a></li>
            </ul>
          </div>
          <div class="sidebar_base"></div>
        </div>
        <div class="sidebar">
          <div class="sidebar_top"></div>
          <div class="sidebar_item">
            <h3>Search</h3>
            <form method="post" action="#" id="search_form">
              <p>
                <input class="search" type="text" name="search_field" value="Enter keywords....." />
                <input name="search" type="image" style="border: 0; margin: 0 0 -9px 5px;" src="style/search.png" alt="Search" title="Search" />
              </p>
            </form>
          </div>
          <div class="sidebar_base"></div>
        </div>
      </div>
      <div id="content">
        <!-- insert the page content here -->
        <h1>HARGA POKOK PRODUKSI</h1>       
          <div class="form_settings">
            <p><span>Biaya Bahan Baku</span><input class="contact" type="text" name="your_name" value="" /></p>
            <p><span>Biaya Tenaga Kerja</span><input class="contact" type="text" name="your_email" value="" /></p>
			<p><span>Biaya Overhead Pabrik</span><input class="contact" type="text" name="your_email" value="" /></p>
            <p style="padding-top: 15px"><span>&nbsp;</span><input class="submit" type="submit" name="contact_submitted" value="submit" /></p>
          </div>       
        <p><br /><br />NOTE: A contact form such as this would require some way of emailing the input to an email address.</p>
      </div>
    </div>
   <div id="content_footer"></div>
    <div id="footer">
      <p><a href="index.html">Beranda</a> | <a href="input_data.php">Input Data</a> | <a href="hitung_harga.php">Hitung Harga</a> | <a href="galeri.php">Galeri</a> | <a href="Laporan.php">Laporan</a></p>
      <p>Copyright &copy; Suweda Rahman Prasetyo</p>
    </div>
  </div>
</body>
</html>